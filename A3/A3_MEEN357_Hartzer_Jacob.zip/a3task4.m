clc; clear all; close all;

A = [10, -1, 2; 1, 10, -1; 2, 3, 20];
B = [4; 3; 7];

x = a3task_GE(A,B);

disp(x)


    